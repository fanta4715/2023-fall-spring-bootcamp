package com.example.firstproject.controller;

import com.example.firstproject.dto.ArticleForm;
import com.example.firstproject.entity.Article;
import com.example.firstproject.repository.ArticleRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

public class ArticleController {

    /*
    구현 목표
    1.       GET    /articles/new       -> new.mustache 반환하기
    2.       POST   /articles/create    -> new.mustache에서 받은 값 저장 후 redirect
    3.       GET    /articles/{id}      -> id에 해당하는 article 이용해서 show.mustache 반환하기
    4.       GET    /articles           -> 값 이용해서 index.mustache 반환하기
    5.       GET    /articles/{id}/edit -> id이용하고, edit.mustache 반환하기
    6.       POST   /aritlces/update    -> edit.mustache에서 받은 값으로 수정 후 redirect
    7.       GET    /articles/{id}/delete->해당 entity 삭제 후 redirect
     */

    //1.       GET    /articles/new       -> new.mustache 반환하기
    @GetMapping("/articles/new")
    public String newArticleForm() {
        /* 채우기 */
    }


    //2.       POST   /articles/create    -> new.mustache에서 받은 값 저장 후 redirect
    @PostMapping("/articles/create")
    public String createArticle(ArticleForm form) {

        /* form데이터 활용해서 저장하고 redirect */

    }

    //3.       GET    /articles/{id}      -> id에 해당하는 article 이용해서 show.mustache 반환하기
    @GetMapping("/articles/{id}") // 데이터 조회 요청 접수
    public String show(@PathVariable Long id, Model model) { // 매개변수로 id 받아오기

        /* id에 해당하는 article 모델에 붙여서 반환 */

    }

    //4.       GET    /articles           -> 값 이용해서 index.mustache 반환하기
    @GetMapping("/articles")
    public String index(Model model) {
        /* 모든 데이터 가져와서 모델에 붙이고 반환 */
    }

    //5.       GET    /articles/{id}/edit -> id이용하고, edit.mustache 반환하기
    @GetMapping("/articles/{id}/edit")
    public String edit(@PathVariable Long id, Model model) {
       /* 수정할 대상의 값을 모델에 붙이고 반환 */
    }

    //6.       POST   /aritlces/update    -> edit.mustache에서 받은 값으로 수정 후 redirect
    @PostMapping("/articles/update")
    public String update(ArticleForm form) {

        /* form에 해당하는 정보로 entity 찾고 갱신후 redirect*/
        
    }

    //7.       GET    /articles/{id}/delete->해당 entity 삭제 후 redirect
    @GetMapping("/articles/{id}/delete")
    public String delete(@PathVariable Long id) {
        /* id에 해당하는 article 삭제 후 redirect*/
    }
}
